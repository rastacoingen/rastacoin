#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/rastacoin.png
ICON_DST=../../src/qt/res/icons/rastacoin.ico
convert ${ICON_SRC} -resize 16x16 rastacoin-16.png
convert ${ICON_SRC} -resize 32x32 rastacoin-32.png
convert ${ICON_SRC} -resize 48x48 rastacoin-48.png
convert rastacoin-16.png rastacoin-32.png rastacoin-48.png ${ICON_DST}

